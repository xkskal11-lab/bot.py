import telebot
from telebot import types
import random
import json
import os

BOT_TOKEN = "8321244924:AAGWjpIlLRhDmnay1QCVDn8HzKEmjcG_oy0"
bot = telebot.TeleBot(BOT_TOKEN, parse_mode="Markdown")

data_file = "data.json"
if not os.path.exists(data_file):
    with open(data_file, "w", encoding="utf-8") as f:
        json.dump({}, f, ensure_ascii=False, indent=4)

def load_data():
    with open(data_file, "r", encoding="utf-8") as f:
        return json.load(f)

def save_data(data):
    with open(data_file, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=4)

def is_admin(chat_id, user_id):
    try:
        member = bot.get_chat_member(chat_id, user_id)
        return member.status in ["administrator", "creator"]
    except:
        return False

@bot.message_handler(func=lambda msg: True)
def handle_all(message):
    chat_id = str(message.chat.id)
    user_id = str(message.from_user.id)
    data = load_data()

    if chat_id not in data:
        data[chat_id] = {"messages": {}, "muted": [], "banned": [], "locked": False, "roulette": None}

    group = data[chat_id]

    # نظام الرسائل
    if user_id not in group["messages"]:
        group["messages"][user_id] = 0
    group["messages"][user_id] += 1
    save_data(data)

    text = message.text or ""

    # منع الكتابة أثناء القفل
    if group["locked"] and not is_admin(chat_id, message.from_user.id):
        try:
            bot.delete_message(chat_id, message.message_id)
        except:
            pass
        return

    # قفل / فتح الشات
    if text == "قفل الشات" and is_admin(chat_id, message.from_user.id):
        if group["locked"]:
            bot.reply_to(message, "⚠️ الشات مقفول بالفعل.")
        else:
            group["locked"] = True
            save_data(data)
            bot.send_message(chat_id, "🔒 تم قفل الشات بنجاح.")
        return

    if text == "فتح الشات" and is_admin(chat_id, message.from_user.id):
        if not group["locked"]:
            bot.reply_to(message, "⚠️ الشات مفتوح بالفعل.")
        else:
            group["locked"] = False
            save_data(data)
            bot.send_message(chat_id, "🔓 تم فتح الشات بنجاح.")
        return

    # نظام الروليت
    if text.startswith("روليت"):
        if not is_admin(chat_id, message.from_user.id):
            return bot.reply_to(message, "🚫 فقط المشرفين يمكنهم إنشاء روليت.")

        if group["roulette"]:
            return bot.reply_to(message, "⚠️ يوجد روليت شغالة، أرسل `انهاء الروليت` أولاً.")

        parts = text.split()
        num_winners = 1
        if len(parts) > 1:
            try:
                num_winners = int(parts[1])
            except:
                pass

        group["roulette"] = {
            "creator": message.from_user.id,
            "players": [],
            "num_winners": num_winners,
            "msg_id": None
        }

        markup = types.InlineKeyboardMarkup()
        markup.add(types.InlineKeyboardButton("مشاركة", callback_data=f"join_{chat_id}"))
        markup.add(types.InlineKeyboardButton("بدء اللعبة", callback_data=f"start_{chat_id}"))

        sent = bot.send_message(chat_id,
            "• مرحباً بكم في لعبة الروليت 👑\n\n"
            "- يمكنكم التسجيل فيها عن طريق ضغط زر مشاركة\n\n"
            f"• عدد اللاعبين : 0\n-",
            reply_markup=markup
        )

        group["roulette"]["msg_id"] = sent.message_id
        save_data(data)
        return

    if text == "انهاء الروليت" and is_admin(chat_id, message.from_user.id):
        if group["roulette"]:
            try:
                bot.delete_message(chat_id, group["roulette"]["msg_id"])
            except:
                pass
            group["roulette"] = None
            save_data(data)
            bot.reply_to(message, "✅ تم إنهاء لعبة الروليت.")
        else:
            bot.reply_to(message, "❌ لا توجد لعبة روليت حالياً.")
        return

    # أوامر المشرفين: كتم، إلغاء كتم، طرد، حظر
    if text.startswith("كتم") and message.reply_to_message and is_admin(chat_id, message.from_user.id):
        target = str(message.reply_to_message.from_user.id)
        if target not in group["muted"]:
            group["muted"].append(target)
            save_data(data)
            bot.reply_to(message, "🔇 تم كتم العضو.")
        return

    if text.startswith("الغاء الكتم") and is_admin(chat_id, message.from_user.id):
        if message.reply_to_message:
            target = str(message.reply_to_message.from_user.id)
        else:
            parts = text.split()
            if len(parts) > 1:
                target = parts[1].replace("@", "")
                try:
                    user = bot.get_chat(target)
                    target = str(user.id)
                except:
                    return bot.reply_to(message, "⚠️ لم أجد المستخدم.")
            else:
                return bot.reply_to(message, "❗ استخدم الرد أو الغاء الكتم @user")

        if target in group["muted"]:
            group["muted"].remove(target)
            save_data(data)
            bot.reply_to(message, "🔊 تم إلغاء الكتم.")
        return

    if text.startswith("طرد") and message.reply_to_message and is_admin(chat_id, message.from_user.id):
        bot.kick_chat_member(chat_id, message.reply_to_message.from_user.id)
        bot.reply_to(message, "🚷 تم طرد العضو.")
        return

    if text.startswith("حظر") and message.reply_to_message and is_admin(chat_id, message.from_user.id):
        target = message.reply_to_message.from_user.id
        bot.ban_chat_member(chat_id, target)
        if str(target) not in group["banned"]:
            group["banned"].append(str(target))
            save_data(data)
        bot.reply_to(message, "⛔ تم حظر العضو نهائياً.")
        return

    if text.startswith("الغاء الحظر") and is_admin(chat_id, message.from_user.id):
        if message.reply_to_message:
            target = message.reply_to_message.from_user.id
        else:
            parts = text.split()
            if len(parts) > 1:
                username = parts[1].replace("@", "")
                try:
                    user = bot.get_chat(username)
                    target = user.id
                except:
                    return bot.reply_to(message, "⚠️ لم أجد المستخدم.")
            else:
                return bot.reply_to(message, "❗ استخدم الرد أو الغاء الحظر @user")

        bot.unban_chat_member(chat_id, target)
        if str(target) in group["banned"]:
            group["banned"].remove(str(target))
            save_data(data)
        bot.reply_to(message, "✅ تم إلغاء الحظر.")
        return

    # الكشف
    if text.lower().startswith("كشف") and message.reply_to_message:
        target = message.reply_to_message.from_user
        uid = str(target.id)
        msg_count = group["messages"].get(uid, 0)
        caption = f"𝑁𝐴𝑀𝐸 ~ {target.first_name}\n𝑈𝐸𝑆𝐸𝑅 ~ @{target.username if target.username else 'لا يوجد'}\n𝐼𝐷 ~ {uid}\n𝑀𝑆𝐺 ~ {msg_count}"
        try:
            bot.send_photo(chat_id, target.photo.big_file_id, caption=caption)
        except:
            bot.send_message(chat_id, caption)
        return

    # رسائلي
    if text.lower() in ["رسايلي", "رسائلي"]:
        count = group["messages"].get(user_id, 0)
        bot.reply_to(message, f"عدد رسائلك بالمجموعة ~ {count}")
        return

    # كتم تلقائي
    if str(message.from_user.id) in group["muted"]:
        try:
            bot.delete_message(chat_id, message.message_id)
        except:
            pass

@bot.callback_query_handler(func=lambda call: True)
def handle_callback(call):
    chat_id = str(call.message.chat.id)
    data = load_data()
    if chat_id not in data or not data[chat_id].get("roulette"):
        return bot.answer_callback_query(call.id, "⚠️ لا توجد لعبة حالياً.", show_alert=True)

    game = data[chat_id]["roulette"]
    user = call.from_user
    if call.data.startswith("join_"):
        if user.id in game["players"]:
            return bot.answer_callback_query(call.id, "❌ انت مشارك بالفعل!", show_alert=True)
        game["players"].append(user.id)
        save_data(data)
        new_text = (f"• مرحباً بكم في لعبة الروليت 👑\n\n"
                    f"- يمكنكم التسجيل فيها عن طريق ضغط زر مشاركة\n\n"
                    f"• عدد اللاعبين : {len(game['players'])}\n-")
        bot.edit_message_text(new_text, call.message.chat.id, call.message.message_id, reply_markup=call.message.reply_markup)
        bot.answer_callback_query(call.id, "✅ تم تسجيل دخولك بنجاح!", show_alert=True)

    elif call.data.startswith("start_"):
        if user.id != game["creator"]:
            return bot.answer_callback_query(call.id, "🚫 فقط من أنشأ اللعبة يمكنه البدء!", show_alert=True)
        players = game["players"]
        num_winners = game["num_winners"]
        if len(players) < num_winners:
            return bot.answer_callback_query(call.id, "❗عدد اللاعبين أقل من عدد الفائزين!", show_alert=True)
        winners = random.sample(players, num_winners)
        result = "• الفائزين في لعبة الروليت 🥳:\n\n"
        for i, w in enumerate(winners, start=1):
            result += f"{i}- [{bot.get_chat_member(call.message.chat.id, w).user.first_name}](tg://user?id={w})\n"
        bot.delete_message(call.message.chat.id, call.message.message_id)
        bot.send_message(call.message.chat.id, result)
        data[chat_id]["roulette"] = None
        save_data(data)

print("✅ البوت يعمل الآن ...")
bot.infinity_polling()